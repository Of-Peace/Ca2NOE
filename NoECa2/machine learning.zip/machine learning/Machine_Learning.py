# ==========================================
# MACHINE LEARNING PROJECT
# Regression & Classification
# Blue Dotted Scatter Chart Only
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import mean_squared_error, r2_score, accuracy_score, classification_report
from imblearn.over_sampling import SMOTE

# ------------------------------------------
# 1. Load Dataset
# ------------------------------------------
df = pd.read_csv(
    "amazon_co-ecommerce_sample.csv",
    encoding="latin1",
    on_bad_lines="skip"
)

print("Dataset Loaded Successfully")
print("Original Shape:", df.shape)

# ------------------------------------------
# 2. Data Cleaning
# ------------------------------------------
df["price"] = df["price"].astype(str).str.replace("£", "", regex=False)
df["price"] = pd.to_numeric(df["price"], errors="coerce")

df["average_review_rating"] = df["average_review_rating"].astype(str).str.extract(r"(\d+\.\d+)")
df["average_review_rating"] = pd.to_numeric(df["average_review_rating"], errors="coerce")

df["number_of_reviews"] = pd.to_numeric(df["number_of_reviews"], errors="coerce")
df["number_of_answered_questions"] = pd.to_numeric(df["number_of_answered_questions"], errors="coerce")

df["main_category"] = df["amazon_category_and_sub_category"].astype(str).str.split(">").str[0].str.strip()

df_model = df[
    ["price", "number_of_reviews", "number_of_answered_questions", "average_review_rating", "main_category"]
].dropna()

print("Cleaned Shape:", df_model.shape)

# ------------------------------------------
# 3. Keep Top 5 Categories
# ------------------------------------------
top_categories = df_model["main_category"].value_counts().nlargest(5).index
df_model = df_model[df_model["main_category"].isin(top_categories)]
print("After Keeping Top 5 Categories:", df_model.shape)

# ------------------------------------------
# 4. Prepare Manufacturer Feature (Optional for Regression/Classification)
# ------------------------------------------
if 'manufacturer' in df.columns:
    df['manufacturer_clean'] = df['manufacturer'].astype(str).str.strip()
elif 'brand' in df.columns:
    df['manufacturer_clean'] = df['brand'].astype(str).str.strip()
else:
    df['manufacturer_clean'] = "Unknown"

top_brands = df['manufacturer_clean'].value_counts().nlargest(5).index
df['manufacturer_top'] = df['manufacturer_clean'].where(df['manufacturer_clean'].isin(top_brands), 'Other')

# ------------------------------------------
# 5. REGRESSION – Predict Price
# ------------------------------------------
X_reg = df_model[["number_of_reviews", "number_of_answered_questions", "average_review_rating"]].copy()
X_brand = pd.get_dummies(df['manufacturer_top'].loc[df_model.index], prefix='brand')
X_reg = pd.concat([X_reg, X_brand], axis=1)
y_reg = df_model["price"]

# Split
X_train_reg, X_test_reg, y_train_reg, y_test_reg = train_test_split(X_reg, y_reg, test_size=0.2, random_state=42)

# Train Linear Regression
lin_reg = LinearRegression()
lin_reg.fit(X_train_reg, y_train_reg)
y_pred_reg = lin_reg.predict(X_test_reg)

# Evaluate Regression
mse = mean_squared_error(y_test_reg, y_pred_reg)
r2 = r2_score(y_test_reg, y_pred_reg)
print("\n==============================")
print("LINEAR REGRESSION PERFORMANCE")
print("==============================")
print("Mean Squared Error:", round(mse,2))
print("R² Score:", round(r2,2))

# ------------------------------------------
# 6. CLASSIFICATION – Predict Main Category
# ------------------------------------------
X_class = df_model[["price", "number_of_reviews", "number_of_answered_questions", "average_review_rating"]].copy()
X_class = pd.concat([X_class, X_brand], axis=1)
y_class = df_model["main_category"]

# Encode target
le = LabelEncoder()
y_encoded = le.fit_transform(y_class)

# Split
X_train, X_test, y_train, y_test = train_test_split(X_class, y_encoded, test_size=0.2, random_state=42)

# Scale numeric features
scaler = StandardScaler()
numeric_cols = ["price", "number_of_reviews", "number_of_answered_questions", "average_review_rating"]
X_train[numeric_cols] = scaler.fit_transform(X_train[numeric_cols])
X_test[numeric_cols] = scaler.transform(X_test[numeric_cols])

# Handle imbalance with SMOTE
sm = SMOTE(random_state=42)
X_train_res, y_train_res = sm.fit_resample(X_train, y_train)

# Train Random Forest Classifier
rf_model = RandomForestClassifier(n_estimators=200, max_depth=10, class_weight='balanced', random_state=42)
rf_model.fit(X_train_res, y_train_res)
y_pred_class = rf_model.predict(X_test)

# Evaluate Classification
accuracy = accuracy_score(y_test, y_pred_class)
print("\n==============================")
print("CLASSIFICATION PERFORMANCE")
print("==============================")
print("Accuracy:", round(accuracy*100,2), "%")
print("\nClassification Report:\n", classification_report(y_test, y_pred_class, zero_division=0))

# ------------------------------------------
# 7. Blue Dotted Scatter Plot (Price vs Reviews)
# ------------------------------------------
plt.figure(figsize=(10,6))
plt.scatter(
    df_model["price"],
    df_model["number_of_reviews"],
    color='blue',
    marker='o',
    alpha=0.5
)
plt.xlabel("Price (£)")
plt.ylabel("Number of Reviews")
plt.title("Amazon Products: Price vs Number of Reviews (Top 5 Categories)")
plt.grid(True, linestyle=':', alpha=0.7)
plt.show()
